import React, { useState } from 'react';
import { TrendingUp, Package, Trash2, Calendar, ShoppingBag, X, Globe } from 'lucide-react';
import { useSales } from '../hooks/useSales';
import { useProductsLite } from '../hooks/useProductsLite';
import { useBusinessCurrency } from '../hooks/useBusinessCurrency';
import { CURRENCIES, currencySymbol, fromBaseUsd, toBaseUsd } from '../utils/currencyUtils';
import { formatBs } from '../utils/calculatorUtils';

const fmtUsd = (v) => v.toFixed(2);
const fmtTime = (iso) => {
    const d = new Date(iso);
    return d.toLocaleTimeString('es-VE', { hour: '2-digit', minute: '2-digit' });
};

export default function SalesView({ theme, triggerHaptic, rates }) {
    const { sales, isLoading, addSale, removeSale, clearAll, getTotals } = useSales();
    const { products, isLoading: productsLoading } = useProductsLite();
    const { mainCurrency } = useBusinessCurrency();
    const sym = currencySymbol(mainCurrency);
    const label = CURRENCIES[mainCurrency];
    const ratesReady = rates?.usdt?.price > 0;

    const [productName, setProductName] = useState('');
    const [qty, setQty] = useState('');
    const [buyPrice, setBuyPrice] = useState('');
    const [sellPrice, setSellPrice] = useState('');
    const [selectedProductId, setSelectedProductId] = useState(null);
    const [showCatalog, setShowCatalog] = useState(false);
    const [catalogSearch, setCatalogSearch] = useState('');
    const [error, setError] = useState('');
    const [deleteConfirmId, setDeleteConfirmId] = useState(null);

    const todayTotals = getTotals('today');
    const todayStr = new Date().toLocaleDateString('es-VE');
    const todaySales = sales.filter(s =>
        new Date(s.createdAt).toLocaleDateString('es-VE') === todayStr
    );

    const handleSelectProduct = (p) => {
        triggerHaptic?.();
        setSelectedProductId(p.id);
        setProductName(p.name);
        setSellPrice(
            ratesReady
                ? fromBaseUsd(p.priceUsdt, mainCurrency, rates).toFixed(2)
                : p.priceUsdt
        );
        setBuyPrice(
            p.costUsdt > 0 && ratesReady
                ? fromBaseUsd(p.costUsdt, mainCurrency, rates).toFixed(2)
                : (p.costUsdt || p.priceUsdt || '')
        );
        setShowCatalog(false);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        triggerHaptic?.();

        if (!selectedProductId || !qty || !buyPrice || !sellPrice) {
            setError('Selecciona un producto y completa los campos');
            setTimeout(() => setError(''), 2500);
            return;
        }

        const q = parseFloat(qty) || 1;
        const bp = parseFloat(buyPrice) || 0;
        const sp = parseFloat(sellPrice) || 0;

        if (q <= 0 || bp < 0 || sp <= 0) {
            setError('Los valores deben ser mayores a 0');
            setTimeout(() => setError(''), 2500);
            return;
        }

        const buyUsd = ratesReady ? toBaseUsd(bp, mainCurrency, rates) : bp;
        const sellUsd = ratesReady ? toBaseUsd(sp, mainCurrency, rates) : sp;

        const profitUnitUsd = sellUsd - buyUsd;
        const profitTotalUsd = profitUnitUsd * q;

        addSale({
            productId: selectedProductId,
            productName: productName,
            qty: q,
            buyPrice: bp,
            sellPrice: sp,
            buyUsd,
            sellUsd,
            profitUnitUsd,
            profitTotalUsd,
            displayCurrency: mainCurrency,
            displayBuy: bp,
            displaySell: sp,
        });

        setProductName('');
        setQty('');
        setBuyPrice('');
        setSellPrice('');
        setSelectedProductId(null);
    };

    const handleClearAll = () => {
        setDeleteConfirmId({ type: 'all' });
    };

    const confirmDelete = () => {
        if (!deleteConfirmId) return;
        triggerHaptic?.();
        if (deleteConfirmId.type === 'single') {
            removeSale(deleteConfirmId.id);
        } else if (deleteConfirmId.type === 'all') {
            clearAll();
        }
        setDeleteConfirmId(null);
    };

    // Buscar nombre de producto del catálogo por ID
    const getProductNameById = (id) => {
        const p = products.find(x => x.id === id);
        return p ? p.name : null;
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-40">
                <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-4 animate-in fade-in duration-300">

            {/* Header */}
            <div>
                <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <TrendingUp size={22} className="text-amber-500" />
                    Zona Revendedor
                </h1>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full w-fit mt-1">
                    <Globe size={12} className="text-amber-500" />
                    <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">
                        Trabajando en {label} · Bs como referencia
                    </span>
                </div>
            </div>

            {/* Resumen del día */}
            <div className="grid grid-cols-3 gap-2">
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Vendido</p>
                    <p className="text-base font-black text-slate-900 dark:text-white mt-0.5 flex flex-wrap items-center justify-center gap-1">
                        {ratesReady ? fmtUsd(fromBaseUsd(todayTotals.totalSoldUsd, mainCurrency, rates)) : '—'}
                        {ratesReady && mainCurrency !== 'USDT' && <span className="text-[11px] text-amber-500 font-bold">{sym}</span>}
                    </p>
                    {ratesReady && mainCurrency === 'USDT' && <p className="text-[10px] text-amber-500 font-bold mt-0.5">{sym}</p>}
                    {ratesReady && <p className="text-[9px] text-slate-400 mt-0.5">≈ {formatBs(todayTotals.totalSoldUsd * rates.usdt.price)} Bs</p>}
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Ganancia</p>
                    <p className={`text-base font-black mt-0.5 flex flex-wrap items-center justify-center gap-1 ${todayTotals.totalProfitUsd >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                        {ratesReady ? fmtUsd(fromBaseUsd(todayTotals.totalProfitUsd, mainCurrency, rates)) : '—'}
                        {ratesReady && mainCurrency !== 'USDT' && <span className="text-[11px] text-emerald-500 font-bold">{sym}</span>}
                    </p>
                    {ratesReady && mainCurrency === 'USDT' && <p className="text-[10px] text-emerald-500 font-bold mt-0.5">{sym}</p>}
                    {ratesReady && <p className="text-[9px] text-slate-400 mt-0.5">≈ {formatBs(todayTotals.totalProfitUsd * rates.usdt.price)} Bs</p>}
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 text-center">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Ventas</p>
                    <p className="text-base font-black text-slate-900 dark:text-white mt-0.5">
                        {todayTotals.count}
                    </p>
                    <p className="text-[9px] text-slate-400 font-bold">hoy</p>
                </div>
            </div>

            {/* Formulario rápido */}
            <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <Package size={12} className="inline mr-1 -mt-0.5" /> Nueva venta
                </p>

                {/* Selector de producto desde catálogo */}
                <div className="space-y-2">
                    <button
                        type="button"
                        onClick={() => { triggerHaptic?.(); setCatalogSearch(''); setShowCatalog(true); }}
                        className={`w-full flex items-center justify-center gap-2 py-3 border rounded-xl text-sm font-bold transition-colors active:scale-[0.98] ${selectedProductId
                            ? 'bg-amber-50 dark:bg-amber-900/10 border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-400'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-amber-500/50 hover:text-amber-500'
                            }`}
                    >
                        <ShoppingBag size={16} />
                        {selectedProductId ? productName : 'Elegir producto del catálogo'}
                    </button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                    <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Cant.</label>
                        <input
                            type="number"
                            placeholder="0"
                            value={qty}
                            onChange={e => setQty(e.target.value)}
                            min="0"
                            step="any"
                            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                        />
                    </div>
                    <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Compra {sym}</label>
                        <input
                            type="number"
                            placeholder="0.00"
                            value={buyPrice}
                            onChange={e => setBuyPrice(e.target.value)}
                            min="0"
                            step="any"
                            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                        />
                    </div>
                    <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Venta {sym}</label>
                        <input
                            type="number"
                            placeholder="0.00"
                            value={sellPrice}
                            onChange={e => setSellPrice(e.target.value)}
                            min="0"
                            step="any"
                            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                        />
                    </div>
                </div>

                {error && (
                    <p className="text-xs text-rose-500 font-bold text-center animate-in fade-in duration-200">
                        {error}
                    </p>
                )}

                <button
                    type="submit"
                    className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-slate-900 font-black text-sm rounded-xl active:scale-[0.98] transition-all shadow-md shadow-amber-500/20"
                >
                    Registrar Venta
                </button>
            </form>

            {/* Lista de ventas de hoy */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">
                    <Calendar size={12} className="inline mr-1 -mt-0.5" /> Ventas de hoy
                </p>

                {todaySales.length === 0 ? (
                    <div className="text-center py-6">
                        <TrendingUp size={28} className="mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                        <p className="text-xs text-slate-400">Sin ventas registradas hoy</p>
                    </div>
                ) : (
                    <div className="space-y-2 max-h-[40vh] overflow-y-auto scrollbar-hide">
                        {todaySales.map(s => {
                            const catalogName = s.productId ? getProductNameById(s.productId) : null;
                            return (
                                <div
                                    key={s.id}
                                    className="flex items-start justify-between gap-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-xl p-3"
                                >
                                    <div className="min-w-0 flex-1">
                                        {(() => {
                                            const saleProfit = typeof s.profitTotalUsd === 'number' ? s.profitTotalUsd : (s.profitUsd || s.profitTotal || 0);
                                            const saleSold = typeof s.sellUsd === 'number' ? s.sellUsd * (s.qty || 1) : (s.totalUsd || s.total || 0);
                                            return (
                                                <>
                                                    <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                                                        {s.productName}
                                                        <span className="text-slate-400 font-normal ml-1 text-xs">
                                                            · {s.qty} × {ratesReady ? `${fmtUsd(fromBaseUsd(saleSold / (s.qty || 1), mainCurrency, rates))}` : '—'} = {ratesReady ? `${fmtUsd(fromBaseUsd(saleSold, mainCurrency, rates))} ${sym}` : '—'}
                                                        </span>
                                                    </p>
                                                    <p className={`text-xs font-bold mt-0.5 ${saleProfit >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                        Ganancia: {ratesReady ? `+${fmtUsd(fromBaseUsd(saleProfit, mainCurrency, rates))} ${sym}` : '— sin datos base'}
                                                    </p>
                                                    {ratesReady && (
                                                        <p className="text-[10px] text-slate-400 mt-0.5">
                                                            ≈ {formatBs(saleProfit * rates.usdt.price)} Bs
                                                        </p>
                                                    )}
                                                </>
                                            );
                                        })()}
                                        {catalogName && (
                                            <p className="text-[9px] text-amber-500/70 font-semibold flex items-center gap-1 mt-0.5">
                                                🔗 {catalogName}
                                            </p>
                                        )}
                                        <p className="text-[9px] text-slate-400 mt-0.5">
                                            {fmtTime(s.createdAt)}
                                        </p>
                                    </div>
                                    <button
                                        onClick={() => { triggerHaptic?.(); setDeleteConfirmId({ type: 'single', id: s.id }); }}
                                        className="shrink-0 p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Limpiar historial */}
            {sales.length > 0 && (
                <button
                    onClick={handleClearAll}
                    className="w-full py-2.5 text-xs font-bold text-slate-400 hover:text-rose-500 transition-colors"
                >
                    Limpiar historial completo ({sales.length} registros)
                </button>
            )}

            {/* Modal Catálogo */}
            {showCatalog && (
                <div
                    className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-end justify-center animate-in fade-in duration-200"
                    onClick={() => setShowCatalog(false)}
                >
                    <div
                        className="w-full max-w-md bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 rounded-t-3xl p-5 pb-8 animate-in slide-in-from-bottom duration-300"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                                <ShoppingBag size={16} className="text-amber-500" /> Catálogo
                            </h3>
                            <button
                                onClick={() => setShowCatalog(false)}
                                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                            >
                                <X size={16} />
                            </button>
                        </div>

                        {productsLoading ? (
                            <div className="text-center py-8">
                                <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                                <p className="text-xs text-slate-400">Cargando catálogo...</p>
                            </div>
                        ) : products.length === 0 ? (
                            <div className="text-center py-8">
                                <ShoppingBag size={28} className="mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                                <p className="text-xs text-slate-400">No tienes productos en el catálogo aún.</p>
                            </div>
                        ) : (
                            <>
                                {/* Búsqueda */}
                                <div className="relative mb-3">
                                    <input
                                        type="text"
                                        placeholder="Buscar producto..."
                                        value={catalogSearch}
                                        onChange={e => setCatalogSearch(e.target.value)}
                                        autoFocus
                                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
                                    />
                                </div>
                                {(() => {
                                    const filtered = products.filter(p =>
                                        p.name.toLowerCase().includes(catalogSearch.toLowerCase())
                                    );
                                    return filtered.length === 0 ? (
                                        <div className="text-center py-6">
                                            <p className="text-xs text-slate-400">No se encontraron productos</p>
                                        </div>
                                    ) : (
                                        <div className="space-y-1.5 max-h-[45vh] overflow-y-auto scrollbar-hide">
                                            {filtered.map(p => (
                                                <button
                                                    key={p.id}
                                                    onClick={() => handleSelectProduct(p)}
                                                    className="w-full flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-xl hover:border-amber-500/40 transition-colors text-left active:scale-[0.98]"
                                                >
                                                    {p.image ? (
                                                        <img
                                                            src={p.image}
                                                            alt={p.name}
                                                            className="w-10 h-10 rounded-lg object-cover shrink-0 bg-slate-200 dark:bg-slate-700"
                                                        />
                                                    ) : (
                                                        <div className="w-10 h-10 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0">
                                                            <Package size={16} className="text-slate-400" />
                                                        </div>
                                                    )}
                                                    <div className="min-w-0 flex-1">
                                                        <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{p.name}</p>
                                                        <p className="text-xs text-amber-500 font-bold">
                                                            {ratesReady
                                                                ? `${fromBaseUsd(p.priceUsdt, mainCurrency, rates).toFixed(2)} ${sym}`
                                                                : `${p.priceUsdt} USDT`
                                                            }
                                                        </p>
                                                        {p.costUsdt && (
                                                            <p className="text-[9px] text-rose-400 font-semibold">
                                                                Costo: {ratesReady ? `${fromBaseUsd(p.costUsdt, mainCurrency, rates).toFixed(2)} ${sym}` : `${p.costUsdt} USDT`}
                                                            </p>
                                                        )}
                                                    </div>
                                                </button>
                                            ))}
                                        </div>
                                    );
                                })()}
                            </>
                        )}
                    </div>
                </div>
            )}

            {/* Modal Confirmar Eliminación */}
            {deleteConfirmId && (
                <div
                    className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-in fade-in duration-200"
                    onClick={() => setDeleteConfirmId(null)}
                >
                    <div
                        className="bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-sm shadow-xl animate-in zoom-in-95 duration-200"
                        onClick={e => e.stopPropagation()}
                    >
                        <div className="flex justify-center mb-4">
                            <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/30 text-rose-500 rounded-full flex items-center justify-center">
                                <Trash2 size={24} />
                            </div>
                        </div>
                        <h3 className="text-lg font-black text-center text-slate-900 dark:text-white mb-2">
                            {deleteConfirmId.type === 'all' ? 'Eliminar Historial' : 'Eliminar Venta'}
                        </h3>
                        <p className="text-sm text-center text-slate-500 dark:text-slate-400 mb-6 font-medium">
                            {deleteConfirmId.type === 'all'
                                ? '¿Estás seguro de que quieres eliminar todo el historial de ventas? Esta acción no se puede deshacer.'
                                : '¿Estás seguro de que quieres eliminar esta venta? Esto afectará los totales de ganancia del día.'
                            }
                        </p>

                        <div className="grid grid-cols-2 gap-3">
                            <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="py-3 px-4 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold rounded-xl transition-colors active:scale-95"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={confirmDelete}
                                className="py-3 px-4 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl transition-colors active:scale-95 shadow-md shadow-rose-500/20"
                            >
                                Sí, eliminar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
